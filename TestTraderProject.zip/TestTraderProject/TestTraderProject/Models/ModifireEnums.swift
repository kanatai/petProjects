//
//  ModifireEnums.swift
//  TestTraderProject
//
//  Created by admin on 20/5/23.
//

import Foundation
import SwiftUI

enum ModifireActionEnums {
    case plus
    case mines
}

enum ModifireTypeEnums {
    case timer
    case investment
}
