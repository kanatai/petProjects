//
//  EnumSellBuy.swift
//  TestTraderProject
//
//  Created by admin on 22/5/23.
//

import Foundation

enum EnumOperation {
    case sell
    case buy
}
